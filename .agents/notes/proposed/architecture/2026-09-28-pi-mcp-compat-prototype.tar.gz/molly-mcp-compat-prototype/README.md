# THROWAWAY: Molly / pi-mcp-adapter compatibility prototype

Question: can small trusted host hooks preserve Molly's grant, dispatch journal and image-result processing boundaries while using the real adapter manager, approval broker, direct executor and MCP SDK?

**Result: feasible for the tested direct-tool path. Not a production migration or an upstream-supported API.**

Baseline: pi-mcp-adapter 3.1.0 at `3ce9716fe6982dfafdea947b316521acb1ebbc73`; MCP client/core 2.0.0. Runtime probe uses Pi 0.85.1 and TypeBox 1.3.7, matching Molly. The adapter manifest and lockfile in this bundle deliberately pin those development dependencies for the experiment. Molly source is copied from `3e91e746b1426e1db8af122e6a833768ec0ba99d`; `prototype/molly-source-manifest.json` records the original paths and hashes. The BrowserTaskApproval declaration is a type-only extract. Other copied Molly runtime files are byte-identical.

`adapter-seams.patch` changes three upstream files and adds one experimental execution module. The source patch injects transport creation into the existing manager and adds an opt-in direct-executor branch. That branch uses the existing approval broker and output guard, with the host journal surrounding a single-use dispatch continuation. It never calls the adapter's session-recovery helper. The manager continues doing actual SDK negotiation/discovery; this is not a fake client implementation. Standard execution remains on its original path.

## Reproduce

Requires Node 22.14+ (tested 22.22.0), npm, and Python 3.9+. Extract this bundle, then run:

```sh
python3 reproduce.py
```

The script creates a new owned temporary checkout, downloads only the exact upstream source archive and locked npm dependencies, skips lifecycle scripts, applies the prototype source patch, recreates the local Molly package link, runs both TypeScript checks, runs the probe with a sanitized environment, then runs the three selected upstream suites. It prints the checkout and report paths. Dependency setup requires network; the compatibility scenarios use injected HTTP responses and no sockets, model APIs or paid tools. Generated receipts/assets stay inside `PROTOTYPE-*` scratch directories and are retained for inspection.

To rerun in the prepared checkout:

```sh
./prototype/run.sh
```

The 30-second watchdog only makes a hung probe fail; no passing assertion depends on time, scheduling luck or sleeps. Image import uses an explicit deferred signal, as do call cancellation and pending approval.

## Evidence

`report.json` records the 21 passing cases. Every synthetic tool/resource request checks that the real Molly journal already persisted its dispatched receipt and epoch before transport. The control case observes stock recovery calling the synthetic server on session-1 and again on session-2. The hosted case observes one request, an unknown receipt after loss, and replay refusal, including through a reopened journal. A new call ID may still execute.

Other cases cover denied/mismatched grants, destination binding, denied/cancelled approvals, revocation and schema changes while permission is pending, list-changed invalidation, single-use continuations, known server failure versus unknown transport outcome, resource denial and URI substitution, late resource-reader expiry, and post-close refusal. The image case holds import open and observes the parent still dispatched, then verifies host-supplied digests replace a forged server receipt. Native keyring modules are absent from the Node require cache. A synthetic credential canary is absent from captured adapter diagnostics and generated receipt/asset files, and no automatic output/blob directories are created in the owned temporary directory.

The owning-host image import callback is a **synthetic stand-in**: it checks the expected fixture bytes, writes a test asset and returns a schema-validated receipt through Molly's real journal. It does not exercise actual ACP caller verification, Electron services, full image decoding or a real design draft.

The bundled reproduction script was also run from a fresh download and locked dependency install on Python 3.9 and Node 22.22.0. Both TypeScript checks passed. Three upstream suites passed: direct tools (56), tool approval (21), session recovery (31), for 108 tests. Their existing internal mocks are upstream code; the compatibility probe inspects protocol requests, on-disk receipts and final results rather than mock call counts.

## Limits and next decision

- No public `createHostedMcpAdapter` factory exists here. The probe constructs trusted extension state and an explicit manager lifetime; full Pi session startup, command suppression, protected native-history rebuild and toolset hashing are not proven.
- Only the direct tool branch has the new boundary. Proxy, script, task, iframe, prompt and generic resource-tool paths are excluded, not migrated or shown safe by these results.
- HTTP transport uses the real SDK with injected Fetch responses and legacy `2025-06-18` negotiation. Real network DNS/redirect behavior, stdio environment isolation, modern protocol negotiation, SDK retry variants and provider compatibility remain untested.
- Catalog comparison in this experiment covers the fixture's single page and input schema. Production adoption must reuse/extend the complete frozen-descriptor, output-schema, pagination and capability contract.
- The cancellation scenario observes a sent cancellation and unknown receipt. Bounded cancellation-delivery failure, close during discovery/import and full Electron teardown remain open.
- No packaged Electron/Node-API acceptance, full native-module load audit or complete log/UI/spill confidentiality audit was performed. A missing keyring module in this Node run is narrower evidence.
- The earlier Codex second-opinion process failed to initialize; this experiment has no independent Codex review.

The first image run failed because the fixture assumed the resource image was content block zero; Molly correctly puts a resource description before it. Only the fixture was corrected. No production code was repaired or changed.

The source changes are throwaway, local and unsubmitted. Upstream discussion: https://github.com/nicobailon/pi-mcp-adapter/issues/716. Molly migration: https://github.com/LeonEthan/molly-design/issues/41. Do not interpret these passing scenarios as permission to replace Molly's production bridge.
