from pathlib import Path

def change(name, old, new):
 p=Path(name);s=p.read_text()
 if s.count(old)!=1: raise RuntimeError(f'{name}: expected unique source anchor: {old[:90]}')
 p.write_text(s.replace(old,new))

change('server-manager.ts','  constructor(private readonly defaultCwd?: string) {}','''  constructor(
    private readonly defaultCwd?: string,
    private readonly prototypeTransport?: {
      create(name: string, signal?: AbortSignal): Promise<Transport>;
      toolsChanged(name: string): void;
    },
  ) {}''')
change('server-manager.ts','    if (definition.command) {\n      client = this.createClient(name, definition);','''    if (this.prototypeTransport) {
      client = this.createClient(name, definition);
      transport = await this.prototypeTransport.create(name, signal);
    } else if (definition.command) {
      client = this.createClient(name, definition);''')
change('server-manager.ts','  private buildClientCapabilities() {\n    return {','''  private buildClientCapabilities() {
    if (this.prototypeTransport) return {};
    return {''')
change('server-manager.ts','              this.handleToolsListChanged(serverName, client, error, tools);','''              this.prototypeTransport?.toolsChanged(serverName);
              this.handleToolsListChanged(serverName, client, error, tools);''')
change('state.ts','export interface McpExtensionState {','''export interface McpExtensionState {
  prototypeHost?: import("./prototype-hosted.ts").PrototypeHost;''')
change('direct-tools.ts','import type { AgentToolResult,','import { executePrototypeHosted } from "./prototype-hosted.ts";\nimport type { AgentToolResult,')
change('direct-tools.ts','    const definition = state.config.mcpServers[spec.serverName];','''    if (state.prototypeHost) {
      return executePrototypeHosted(state, spec, toolCallId, params, signal);
    }

    const definition = state.config.mcpServers[spec.serverName];''')
