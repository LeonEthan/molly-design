from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request

bundle = Path(__file__).resolve().parent
checkout = Path(tempfile.mkdtemp(prefix="molly-mcp-compat-prototype-"))
commit = "3ce9716fe6982dfafdea947b316521acb1ebbc73"
archive = checkout / "upstream.tar.gz"
with urllib.request.urlopen(f"https://codeload.github.com/nicobailon/pi-mcp-adapter/tar.gz/{commit}") as response:
    archive.write_bytes(response.read())
with tarfile.open(archive) as source:
    destination = checkout / "source"
    for member in source.getmembers():
        target = (destination / member.name).resolve()
        if destination.resolve() not in target.parents or not (member.isfile() or member.isdir()):
            raise ValueError(f"Unsupported archive entry: {member.name}")
    source.extractall(destination)
source_root = checkout / "source" / f"pi-mcp-adapter-{commit}"
for item in source_root.iterdir():
    shutil.move(str(item), checkout / item.name)
for filename in ["package.json", "package-lock.json", "prototype-hosted.ts"]:
    shutil.copyfile(bundle / filename, checkout / filename)
shutil.copytree(bundle / "prototype", checkout / "prototype")
manifest = json.loads((checkout / "prototype/molly-source-manifest.json").read_text())
for path, evidence in manifest["files"].items():
    assert hashlib.sha256((checkout / path).read_bytes()).hexdigest() == evidence["sha256"], path
subprocess.run(["python3", "prototype/patch-adapter.py"], cwd=checkout, check=True)
subprocess.run(["npm", "ci", "--ignore-scripts", "--no-audit", "--no-fund", "--cache", str(checkout / ".npm-cache")], cwd=checkout, check=True)
(checkout / "node_modules/@molly").mkdir(exist_ok=True)
(checkout / "node_modules/@molly/shared").symlink_to("../../prototype/molly-shared")
(checkout / "prototype/run.sh").chmod(0o755)
subprocess.run(["node_modules/.bin/tsc", "--noEmit"], cwd=checkout, check=True)
subprocess.run(["node_modules/.bin/tsc", "--noEmit", "-p", "prototype/tsconfig.json"], cwd=checkout, check=True)
subprocess.run(["./prototype/run.sh"], cwd=checkout, check=True)
subprocess.run(["node_modules/.bin/vitest", "run", "__tests__/direct-tools.test.ts", "__tests__/tool-approval.test.ts", "__tests__/session-recovery.test.ts"], cwd=checkout, check=True)
print(f"Isolated checkout: {checkout}")
print((checkout / "prototype/latest-report-path.txt").read_text().strip())
