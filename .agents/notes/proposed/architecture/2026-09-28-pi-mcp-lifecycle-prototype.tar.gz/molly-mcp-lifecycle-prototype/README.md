# THROWAWAY: Molly / pi-mcp-adapter hosted lifecycle compatibility

Question: can an explicitly admitted, single-run hosted entry point use the real adapter and Pi extension lifecycle while keeping startup, publication, cancellation and teardown within Molly's existing ownership boundary?

**Verdict: feasible for the tested direct-tool hosted entry point. This is an experimental source patch, not an upstream API or a production migration.** The extension uses Pi's real public resource loader and extension runner, the adapter's runtime owner, manager, approval broker and direct executor, and the real MCP SDK HTTP transport with injected responses. It does not enter the ordinary adapter initializer, which owns configuration/OAuth/management behavior outside this experiment's admitted profile. Ordinary extension regression tests continue exercising that initializer.

## Run

Requires Python 3.9+, npm and Node 22.14+ (tested Node 22.22.0). Extract this bundle and run:

```sh
python3 reproduce.py
```

This makes an owned temporary checkout, downloads pi-mcp-adapter commit `3ce9716fe6982dfafdea947b316521acb1ebbc73` (3.1.0), installs the locked dependencies with lifecycle scripts disabled, applies the patch, and runs both TypeScript checks, the direct probe, the lifecycle probe and seven upstream suites. Pi is pinned to 0.85.1 and TypeBox to 1.3.7, matching the original Molly experiment; MCP client/core are 2.0.0. Only setup uses network. New scenarios use synthetic responses, no sockets, model/provider calls or paid operations.

The script prints its checkout and report paths. In that checkout, rerun `./prototype/run.sh` or `./prototype/run-lifecycle.sh`. Both scripts sanitize the process environment and own their temporary data. The lifecycle script rejects any unexpected global Fetch use. Deferred gates control every race; the injected cleanup deadline is advanced explicitly. The 30-second watchdog can only fail a stuck probe, never make it pass. The experimental real deadline default is one second, not a proposed product timeout.

`adapter-seams.patch` shows all changes against the pinned upstream source: three existing files plus `prototype-hosted.ts` and `prototype-lifecycle.ts`. `prototype/patch-adapter.py` applies the three existing-file seams, while reproduction copies the two experimental modules. `prototype/molly-source-manifest.json` records byte-identical copied Molly runtime sources at `3e91e746b1426e1db8af122e6a833768ec0ba99d` and the one type-only extraction. This bundle preserves both projects' licenses and contains no installed dependencies, machine configuration or captured conversations.

## What changed from the first prototype

The new entry point has an extension factory, an explicit `ready()` check, bounded `close()`, and a diagnostic `cleanup` promise for eventual drain. It admits the complete selection before acquiring transports, awaits discovery for all servers, checks grants again, validates names against existing Pi tools, then registers direct tools. It registers no management commands, flags, proxy/script tools or resource-discovery hooks. Each instance belongs to one run; repeated session startup retires it. A replacement uses a new instance and a fresh grant.

Closing synchronously fences dispatch and revokes the host grant before asynchronous cleanup. It awaits startup, manager cleanup and owned execution/transport-send promises. A deadline returns `incomplete`; actual later drain is observed separately. Uncertain delivery remains unknown, and a pending image import remains dispatched until it rejects/settles. Host result processing receives the operation's abort signal; the fixture checks it before the synthetic import side effect. A failed or incomplete shutdown also surfaces a fixed error through Pi's runner, whose error listener is necessary because Pi catches hook exceptions.

The first late-factory test exposed an ownership gap in the initial transport seam: if close happened before the factory returned, the SDK client did not yet own the returned transport, so `client.close()` did not dispose it. The seam now explicitly disposes an aborted late transport before attempting SDK connection. This changes only the throwaway adapter patch. A separate initial fixture error used the journal's recovery read to observe an in-flight receipt; that API intentionally maps dispatched to unknown. The fixture now reads the durable file directly, as the original direct probe does.

## Evidence

`direct-report.json`: the original 21 scenarios still pass, including durable dispatch/no replay, broker decisions, resource identity, host image receipts and diagnostic canaries.

`lifecycle-report.json`: 23 additional scenarios pass:

- Loading has no connection or tool publication; awaited startup publishes only admitted direct tools after discovery, without commands or flags.
- Missing grants, close before startup, close during factory/handshake/discovery, restart during discovery, revoked grants, failed discovery and partial multi-server failure never publish a ready catalog.
- A disposal failure from a late factory is preserved as a cleanup failure. Closing a pending approval prevents dispatch. Closing a dispatched call sends cancellation, preserves an unknown receipt and refuses late calls without reconnecting.
- Stalled cancellation delivery, stalled transport close and held host import exercise the explicit deadline and eventual drain. Cancellation-send and transport-close failures remain observable; shutdown-hook failure is reported through the real runner.
- Registration collisions preserve the existing tool; registration exceptions retire the instance. Old callbacks remain retired after a new instance admits the same server with a distinct run and epoch. `ready()` rejects after retirement.

The final bundle was reconstructed from a fresh upstream download and locked dependency install. Both synthetic reports matched the original run exactly. Both TypeScript checks pass. Seven unchanged upstream suites pass 279 tests: direct tools, approval, session recovery, runtime owner, server-manager close ownership, server-manager runtime ownership and index lifecycle. The lifecycle audit inspects debug diagnostics and runner errors for a synthetic credential sentinel, including Error object text, and confirms no unexpected global Fetch invocation.

## Limits

- This is a separate experimental source entry point. It is not exported by the upstream package, installed in Molly or negotiated with upstream. Upstream acceptance remains unresolved in issue #716.
- The real Pi loader/runner is exercised, not an entire AgentSession, inference loop, protected native-history rebuild, model-context/toolset hash or application runtime. Retired runners retain registered tool definitions because Pi has no unregister API; their callbacks fail closed. The host must await readiness and inspect close outcomes/errors.
- This validates only direct execution and a synthetic abort-aware host import callback. Actual ACP caller verification, image decoding/import, Electron services, packaged native-module acceptance and stdio/provider behavior remain untested.
- The injected responses negotiate legacy `2025-06-18`. Real DNS/redirect behavior, modern protocol negotiation and other SDK retry variants remain open. This does not audit every upstream execution or logging path.
- Catalog checks still do not establish the complete frozen-descriptor/output-schema/pagination contract. Prompt, proxy, script, task, iframe and generic resource-tool paths remain outside the profile.
- Bounded close cannot force an uncooperative transport factory or host callback to finish or prove remote cancellation. A timeout reports incomplete cleanup. Host credential revocation and callback fencing are observed; garbage collection or erasure of pending stacks is not claimed.
- Independent Codex review remains unavailable after the earlier CLI initialization failure; no automatic retry was made.

The next production-facing gate is actual host import and packaged runtime acceptance, together with an agreed upstream API. These results authorize no bridge replacement. Molly runtime code and workspace dependencies remain unchanged.
