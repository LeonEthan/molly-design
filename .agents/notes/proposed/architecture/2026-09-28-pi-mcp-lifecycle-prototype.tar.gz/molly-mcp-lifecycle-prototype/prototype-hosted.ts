import { createHash } from "node:crypto";
import type { McpExtensionState } from "./state.ts";
import type { DirectToolSpec } from "./types.ts";
import { ensureToolCallApproved } from "./tool-approval.ts";
import { guardMcpOutput, resolveMcpOutputGuardOptions } from "./mcp-output-guard.ts";
import { resolveMcpResultContent } from "./tool-registrar.ts";

export interface PrototypeOperation {
  toolCallId: string;
  serverName: string;
  toolName: string;
  args: Record<string, unknown>;
  connectionIdentity: symbol;
  parentToolCallId?: string;
}

type Send = () => Promise<unknown>;
export type PrototypeChildDispatch = (operation: PrototypeOperation, send: Send) => Promise<unknown>;
export type PrototypeResourceRead = (uri: string, toolCallId: string, dispatch: PrototypeChildDispatch) => Promise<unknown>;
export interface PrototypeHost {
  signal: AbortSignal;
  available(serverName: string): boolean;
  dispatch(operation: PrototypeOperation, send: Send, read: PrototypeResourceRead, signal: AbortSignal): Promise<unknown>;
}

const identities = new WeakMap<object, symbol>();
const digest = (value: unknown) => createHash("sha256").update(JSON.stringify(value)).digest("hex");

function freeze<T>(value: T): T {
  if (value && typeof value === "object") {
    for (const nested of Object.values(value)) freeze(nested);
    Object.freeze(value);
  }
  return value;
}

export async function executePrototypeHosted(
  state: McpExtensionState,
  spec: DirectToolSpec,
  toolCallId: string,
  params: Record<string, unknown>,
  signal?: AbortSignal,
) {
  const host = state.prototypeHost!;
  const ownedSignal = AbortSignal.any([host.signal, ...(signal ? [signal] : [])]);
  const connection = state.manager.getConnection(spec.serverName);
  const assertAvailable = () => {
    ownedSignal.throwIfAborted();
    if (!host.available(spec.serverName) || !connection || connection.status !== "connected"
      || state.manager.getConnection(spec.serverName) !== connection) throw new Error("prototype_connection_retired");
  };
  try {
    assertAvailable();
    const active = connection!;
    let connectionIdentity = identities.get(active);
    if (!connectionIdentity) {
      connectionIdentity = Symbol("prototype-connection");
      identities.set(active, connectionIdentity);
    }
    const expected = state.toolMetadata.get(spec.serverName)?.find(tool => tool.originalName === spec.originalName);
    if (!expected) throw new Error("prototype_tool_unavailable");
    const fingerprint = digest({ name: expected.originalName, inputSchema: expected.inputSchema });
    const checkSchema = async () => {
      assertAvailable();
      const catalog = await active.client.listTools(undefined, { signal: ownedSignal, cacheMode: "refresh" });
      assertAvailable();
      const tool = catalog.tools.find(entry => entry.name === spec.originalName);
      if (!tool || digest({ name: tool.name, inputSchema: tool.inputSchema }) !== fingerprint)
        throw new Error("prototype_schema_changed");
    };
    const args = freeze(structuredClone(params));
    await checkSchema();
    const approval = await ensureToolCallApproved(state, spec.serverName, expected, args, ownedSignal, "direct");
    if (!approval.ok) throw new Error("prototype_permission_denied");
    await checkSchema();
    const operation: PrototypeOperation = freeze({ toolCallId, serverName: spec.serverName,
      toolName: spec.originalName, args, connectionIdentity });
    let open = true;
    let dispatched = false;
    const assertOpen = () => {
      assertAvailable();
      if (!open) throw new Error("prototype_operation_expired");
    };
    const send = async () => {
      assertOpen();
      if (dispatched) throw new Error("prototype_continuation_replayed");
      dispatched = true;
      return await active.client.callTool({ name: spec.originalName, arguments: args }, { signal: ownedSignal });
    };
    const read: PrototypeResourceRead = async (uri, childId, dispatch) => {
      assertOpen();
      const childArgs = freeze({ uri });
      const decision = await ensureToolCallApproved(state, spec.serverName,
        { name: "prototype_resource", originalName: "resources/read", description: "Read the producing connection's resource", resourceUri: uri },
        childArgs, ownedSignal, "resource");
      if (!decision.ok) throw new Error("prototype_resource_denied");
      await checkSchema();
      assertOpen();
      let sent = false;
      return await dispatch(freeze({ toolCallId: childId, serverName: spec.serverName,
        toolName: "resources/read", args: childArgs, connectionIdentity, parentToolCallId: toolCallId }), async () => {
        assertOpen();
        if (sent) throw new Error("prototype_child_replayed");
        sent = true;
        return await active.client.readResource({ uri }, { signal: ownedSignal });
      });
    };
    let result: unknown;
    try {
      result = await host.dispatch(operation, send, read, ownedSignal);
      assertAvailable();
    } finally {
      open = false;
    }
    const record = result as Record<string, unknown>;
    const content = resolveMcpResultContent(record);
    const guarded = await guardMcpOutput(content, {
      ...resolveMcpOutputGuardOptions(state.config.settings),
      ...(record.isError === true ? { prefix: "Error: " } : {}),
    });
    return { content: guarded.content, details: { server: spec.serverName, hosted: true } };
  } catch {
    return { content: [{ type: "text" as const, text: "prototype_host_operation_failed" }],
      details: { error: "prototype_host_operation_failed" } };
  }
}
