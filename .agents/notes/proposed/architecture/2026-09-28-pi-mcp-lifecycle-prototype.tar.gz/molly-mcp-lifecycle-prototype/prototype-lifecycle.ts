import type { ExtensionAPI, ExtensionFactory } from "@earendil-works/pi-coding-agent";
import type { Transport } from "./types.ts";
import type { TSchema } from "typebox";
import { McpServerManager } from "./server-manager.ts";
import { createMcpRuntimeOwner } from "./runtime-owner.ts";
import { createDirectToolExecutor } from "./direct-tools.ts";
import type { McpExtensionState } from "./state.ts";
import type { PrototypeHost } from "./prototype-hosted.ts";

export interface PrototypeLifecycleOptions {
  cwd: string;
  servers: readonly string[];
  host: PrototypeHost;
  validateGrant(server: string): void;
  createTransport(server: string, signal: AbortSignal): Promise<Transport>;
  releaseGrant(): void;
  scheduleDeadline?(expire: () => void): () => void;
}

export function createPrototypeHostedAdapter(options: PrototypeLifecycleOptions) {
  const owner = createMcpRuntimeOwner();
  const servers = [...options.servers];
  if (new Set(servers).size !== servers.length || servers.some(name => !/^[a-z][a-z0-9_-]*$/.test(name)))
    throw new Error("prototype_invalid_selection");
  let phase: "idle" | "starting" | "ready" | "closing" | "closed" = "idle";
  let capabilities: PrototypeLifecycleOptions | undefined = options;
  const active = new Set<Promise<unknown>>();
  let startup: Promise<void> | undefined;
  let closePromise: Promise<{ status: "closed" | "incomplete"; cleanupFailed: boolean }> | undefined;
  let installed = false;
  let cancellationDeliveryFailed = false;
  let cleanupResolve!: () => void;
  const cleanup = new Promise<void>(resolve => { cleanupResolve = resolve; });
  let readyResolve!: () => void;
  let readyReject!: (error: Error) => void;
  const ready = new Promise<void>((resolve, reject) => { readyResolve = resolve; readyReject = reject; });
  void ready.catch(() => {});
  const manager = new McpServerManager(options.cwd, {
    async create(name, signal) {
      const host = capabilities;
      owner.throwIfInactive();
      if (!host || !servers.includes(name)) throw new Error("prototype_unadmitted_server");
      host.validateGrant(name);
      const transport = await host.createTransport(name, AbortSignal.any([owner.signal, ...(signal ? [signal] : [])]));
      const send = transport.send.bind(transport);
      transport.send = (...args) => observe(send(...args).catch(error => {
        if ("method" in args[0] && args[0].method === "notifications/cancelled") cancellationDeliveryFailed = true;
        throw error;
      }));
      return transport;
    },
    toolsChanged() { void close(); },
  });
  manager.setRuntimeSignal(owner.signal);
  const definition = { command: "PROTOTYPE-supplied-transport", auth: false as const, oauth: false as const,
    tasks: false, protocolVersion: "legacy" as const };
  const state = {
    owner, manager, config: { mcpServers: Object.fromEntries(servers.map(name => [name, { ...definition }])),
      settings: { approveTools: true, autoAuth: false, sampling: false, elicitation: false, scriptMode: false,
        allowInstall: false, namespaceProxyTools: false, exposeResources: false, jev: false } },
    toolMetadata: new Map(), approvedToolCalls: new Map(), approvedServers: new Map(),
    completedUiSessions: [], failureTracker: new Map(), failureMessages: new Map(),
    prototypeHost: {
      signal: owner.signal,
      available(name: string) { return phase === "ready" && capabilities?.host.available(name) === true; },
      async dispatch(...args: Parameters<PrototypeHost["dispatch"]>) {
        owner.throwIfInactive();
        const host = capabilities;
        if (!host) throw new Error("prototype_retired");
        return await host.host.dispatch(...args);
      },
    },
  } as unknown as McpExtensionState;
  owner.addCleanup(async () => {
    try { await manager.closeAll(); } catch { throw new Error("prototype_cleanup_failed"); }
  });
  const observe = <T>(work: Promise<T>) => {
    active.add(work);
    void work.finally(() => active.delete(work)).catch(() => {});
    return work;
  };
  const scheduleDeadline = options.scheduleDeadline ?? (expire => {
    const timer = setTimeout(expire, 1_000);
    return () => clearTimeout(timer);
  });
  const hostSignal = options.host.signal;
  function close() {
    if (closePromise) return closePromise;
    phase = "closing";
    readyReject(new Error("prototype_not_ready"));
    hostSignal.removeEventListener("abort", onHostAbort);
    const stop = owner.stop("prototype_closed");
    const release = capabilities?.releaseGrant;
    capabilities = undefined;
    let releaseFailed = false;
    try { release?.(); } catch { releaseFailed = true; }
    const drained = Promise.allSettled([stop, ...(startup ? [startup] : [])]).then(async outcomes => {
      while (active.size) await Promise.allSettled([...active]);
      state.toolMetadata.clear();
      state.approvedToolCalls.clear();
      state.approvedServers?.clear();
      delete state.approvalEvents;
      phase = "closed";
      cleanupResolve();
      return { status: "closed" as const, cleanupFailed: releaseFailed || cancellationDeliveryFailed || outcomes[0]?.status === "rejected" };
    });
    closePromise = new Promise(resolve => {
      const cancelDeadline = scheduleDeadline(() => resolve({ status: "incomplete", cleanupFailed: releaseFailed }));
      void drained.then(result => { cancelDeadline(); resolve(result); });
    });
    return closePromise;
  }
  function onHostAbort() { void close(); }
  hostSignal.addEventListener("abort", onHostAbort, { once: true });
  if (hostSignal.aborted) void close();

  const extension: ExtensionFactory = (pi: ExtensionAPI) => {
    if (installed || phase !== "idle") throw new Error("prototype_instance_retired_or_installed");
    installed = true;
    state.approvalEvents = pi.events;
    pi.on("session_start", async () => {
      if (phase !== "idle") {
        await close();
        throw new Error("prototype_fresh_instance_required");
      }
      phase = "starting";
      startup = (async () => {
        try {
          for (const name of servers) capabilities!.validateGrant(name);
          const connections = await Promise.all(servers.map(name => manager.connect(name, definition, owner.signal)));
          owner.throwIfInactive();
          for (const name of servers) capabilities!.validateGrant(name);
          const reserved = new Set(pi.getAllTools().map(tool => tool.name));
          const registrations = connections.flatMap((connection, index) => {
            const name = servers[index]!;
            if (connection.status !== "connected") throw new Error("prototype_discovery_failed");
            const metadata = connection.tools.map(tool => ({ name: `${name}_${tool.name}`, originalName: tool.name,
              description: tool.description ?? "", inputSchema: structuredClone(tool.inputSchema ?? { type: "object" }) }));
            state.toolMetadata.set(name, metadata);
            return metadata.map(tool => {
              if (reserved.has(tool.name)) throw new Error("prototype_tool_collision");
              reserved.add(tool.name);
              const spec = { serverName: name, originalName: tool.originalName, prefixedName: tool.name,
                description: tool.description, inputSchema: tool.inputSchema };
              const execute = createDirectToolExecutor(() => state, () => null, spec);
              return { name: tool.name, label: tool.name, description: tool.description,
                parameters: structuredClone(tool.inputSchema) as TSchema,
                execute: (...args: Parameters<typeof execute>) => observe(execute(...args)) };
            });
          });
          for (const tool of registrations) {
            owner.throwIfInactive();
            pi.registerTool(tool);
          }
          owner.throwIfInactive();
          phase = "ready";
          readyResolve();
        } catch {
          readyReject(new Error("prototype_startup_failed"));
          throw new Error("prototype_startup_failed");
        }
      })();
      try { await startup; } catch {
        await close();
        throw new Error("prototype_startup_failed");
      }
    });
    pi.on("before_agent_start", () => {
      if (phase !== "ready") throw new Error("prototype_not_ready");
    });
    pi.on("session_shutdown", async () => {
      const result = await close();
      if (result.status !== "closed" || result.cleanupFailed) throw new Error("prototype_cleanup_incomplete");
    });
  };
  return { extension, close, cleanup,
    async ready() {
      await ready;
      owner.throwIfInactive();
      if (phase !== "ready") throw new Error("prototype_not_ready");
    },
    snapshot: () => ({ phase, pending: active.size, connections: servers.filter(name => manager.getConnection(name) !== undefined),
      retainedGrant: capabilities !== undefined, retainedMetadata: state.toolMetadata.size }) };
}
