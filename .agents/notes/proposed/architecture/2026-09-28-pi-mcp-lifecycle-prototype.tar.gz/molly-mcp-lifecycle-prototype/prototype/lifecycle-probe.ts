import assert from "node:assert/strict";
import { inspect } from "node:util";
import { createHash } from "node:crypto";
import { mkdtemp, mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { DefaultResourceLoader, SettingsManager, ExtensionRunner, SessionManager, ModelRuntime, ModelRegistry, createEventBus } from "@earendil-works/pi-coding-agent";
import { InMemoryCredentialStore, InMemoryModelsStore } from "@earendil-works/pi-ai";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/client";
import { createPrototypeHostedAdapter } from "../prototype-lifecycle.ts";
import { MCP_TOOL_APPROVAL_REQUEST_EVENT, type McpToolApprovalRequest } from "../types.ts";
import { ToolOperationJournal } from "./molly/tool-operation-journal.ts";
import { abortable } from "../abort.ts";
import { logger } from "../logger.ts";

const root = await mkdtemp(join(import.meta.dirname, "PROTOTYPE-lifecycle-"));
const diagnostics: unknown[] = [];
logger.setLevel("debug");
logger.addHandler(({ timestamp, ...entry }) => diagnostics.push(entry));
const originalError = console.error;
console.error = (...args) => { diagnostics.push(args); };
let unexpectedNetwork = false;
globalThis.fetch = async () => { unexpectedNetwork = true; throw new Error("prototype_unexpected_network"); };
const watchdog = setTimeout(() => { process.stderr.write("Lifecycle probe did not settle\n"); process.exit(1); }, 30_000);
watchdog.unref();
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}
function gate() {
  const entered = deferred<void>();
  const released = deferred<void>();
  return { entered: entered.promise, release: () => released.resolve(),
    wait: () => { entered.resolve(); return released.promise; } };
}
const modelRuntime = await ModelRuntime.create({ credentials: new InMemoryCredentialStore(), modelsStore: new InMemoryModelsStore(),
  modelsPath: null, allowModelNetwork: false, refreshOnCreate: false });
const results: Array<{ name: string; evidence: unknown }> = [];

async function fixture(name: string, config: { stage?: string; failedServer?: string; servers?: string[]; admitted?: boolean; closeFails?: boolean; cancelFails?: boolean; collision?: boolean; registerFails?: boolean } = {}) {
  const directory = join(root, name);
  await mkdir(directory);
  const runId = createHash("sha256").update(name).digest("hex");
  const epoch = `${runId.slice(0,8)}-${runId.slice(8,12)}-4${runId.slice(13,16)}-8${runId.slice(17,20)}-${runId.slice(20,32)}`;
  const journal = new ToolOperationJournal(join(directory, "receipts"));
  const bus = createEventBus();
  const hostController = new AbortController();
  let admitted = config.admitted !== false;
  let released = false;
  let expire: (() => void) | undefined;
  let imported = false;
  let parentSignal: AbortSignal | undefined;
  let receiptId = "operation";
  const paused = gate();
  const cancelDelivery = gate();
  const transportClose = gate();
  const deadlineArmed = deferred<void>();
  const trace: string[] = [];
  const wire: Array<{ server: string; method: string; receipt?: string }> = [];
  const closedTransports = new Set<string>();
  const errors: unknown[] = [];
  const canary = "synthetic-lifecycle-credential";
  bus.on(MCP_TOOL_APPROVAL_REQUEST_EVENT, raw => {
    const request = raw as McpToolApprovalRequest;
    request.claim(async () => {
      if (config.stage === "approval") await paused.wait();
      return "allow_once" as const;
    });
  });
  const adapter = createPrototypeHostedAdapter({
    cwd: directory, servers: config.servers ?? ["synthetic"],
    validateGrant(server) {
      if (!admitted || released) throw new Error(canary);
      trace.push(`grant:${server}`);
    },
    releaseGrant() { released = true; admitted = false; trace.push("grant-released"); },
    scheduleDeadline(fire) { expire = fire; deadlineArmed.resolve(); return () => { expire = undefined; }; },
    async createTransport(server, signal) {
      trace.push(`factory:${server}`);
      if (config.stage === "factory") await paused.wait();
      const endpoint = `https://${server}.prototype.invalid/mcp`;
      const json = (id: unknown, result: unknown, headers = {}) => new Response(JSON.stringify({ jsonrpc: "2.0", id, result }),
        { headers: { "content-type": "application/json", ...headers } });
      const transport = new StreamableHTTPClientTransport(new URL(endpoint), {
        reconnectionOptions: { maxRetries: 0, initialReconnectionDelay: 1, maxReconnectionDelay: 1, reconnectionDelayGrowFactor: 1 },
        requestInit: { headers: { "x-prototype-credential": canary } },
        fetch: async (input, init) => {
          const request = new Request(input, init);
          assert.equal(request.url, endpoint);
          assert.equal(request.headers.get("x-prototype-credential"), canary);
          if (request.method === "GET") return new Response(null, { status: 405 });
          if (request.method === "DELETE") return new Response(null, { status: 202 });
          const message = JSON.parse(await request.text());
          trace.push(`${server}:${message.method}`);
          wire.push({ server, method: message.method });
          if (message.method === "initialize") {
            assert.deepEqual(message.params.capabilities, {});
            if (config.stage === "handshake") await paused.wait();
            return json(message.id, { protocolVersion: "2025-06-18", serverInfo: { name: server, version: "1" }, capabilities: { tools: {} } },
              { "mcp-session-id": server });
          }
          if (message.method === "tools/list") {
            if (config.stage === "discovery") await paused.wait();
            if (config.failedServer === server) return new Response(canary, { status: 500 });
            return json(message.id, { tools: [{ name: "charge", description: "Synthetic lifecycle operation", inputSchema: { type: "object", properties: {} } }] });
          }
          if (message.method === "tools/call") {
            const record = JSON.parse(await readFile(join(directory, "receipts", `${journal.operationId(runId, receiptId)}.json`), "utf8"));
            assert.equal(record?.state, "dispatched");
            wire.at(-1)!.receipt = receiptId;
            if (config.stage === "call" || config.stage === "cancel-delivery") await abortable(paused.wait(), request.signal);
            return json(message.id, { content: [{ type: "text", text: "synthetic success" }] });
          }
          if (message.method === "notifications/cancelled") {
            if (config.stage === "cancel-delivery") await cancelDelivery.wait();
            if (config.cancelFails) throw new Error(canary);
            return new Response(null, { status: 202 });
          }
          if (message.method.startsWith("notifications/")) return new Response(null, { status: 202 });
          throw new Error("prototype_unexpected_method");
        },
      });
      const actualClose = transport.close.bind(transport);
      transport.close = async () => {
        await actualClose();
        closedTransports.add(server);
        trace.push(`transport-closed:${server}`);
        if (config.stage === "close") await transportClose.wait();
        if (config.closeFails) throw new Error(canary);
      };
      return transport;
    },
    host: {
      signal: hostController.signal,
      available: () => admitted && !released,
      async dispatch(operation, send, _read, signal) {
        receiptId = operation.toolCallId;
        parentSignal = signal;
        return await journal.dispatch({ snapshot: { runId, runtimeEpoch: epoch }, connectionId: "workspace:synthetic", connectionRevision: 1,
          toolCallId: operation.toolCallId, toolName: operation.toolName, arguments: operation.args,
          ...(config.stage === "import" ? { externalImage: true, importImages: async () => {
            await paused.wait();
            signal.throwIfAborted();
            imported = true;
            throw new Error("prototype_import_should_have_been_cancelled");
          } } : {}),
        }, send);
      },
    },
  });
  const loader = new DefaultResourceLoader({ cwd: directory, agentDir: join(directory, "agent"),
    settingsManager: SettingsManager.inMemory(), eventBus: bus, extensionFactories: [(pi) => {
      if (config.collision) pi.registerTool({ name: "synthetic_charge", label: "Existing", description: "Reserved fixture tool", parameters: { type: "object" },
        execute: async () => ({ content: [{ type: "text", text: "reserved" }], details: {} }) });
      if (config.registerFails) pi.registerTool = () => { throw new Error(canary); };
      return adapter.extension(pi);
    }],
    noExtensions: true, noSkills: true, noPromptTemplates: true, noThemes: true, noContextFiles: true, systemPrompt: "Synthetic lifecycle fixture" });
  await loader.reload();
  const loaded = loader.getExtensions();
  assert.deepEqual(loaded.errors, []);
  const runner = new ExtensionRunner(loaded.extensions, loaded.runtime, directory, SessionManager.inMemory(directory), new ModelRegistry(modelRuntime));
  loaded.runtime.getAllTools = () => runner.getAllRegisteredTools().map(({ definition, sourceInfo }) => ({ name: definition.name, description: definition.description, parameters: definition.parameters, sourceInfo }));
  runner.onError(error => { errors.push({ event: error.event, error: error.error }); });
  assert.equal(wire.length, 0, "loading a hosted extension cannot acquire a connection");
  assert.deepEqual(runner.getRegisteredCommands(), []);
  assert.equal(runner.getFlags().size, 0);
  if (!config.collision) assert.deepEqual(runner.getAllRegisteredTools(), []);
  return { adapter, runner, paused, cancelDelivery, transportClose, deadlineArmed, trace, wire, errors, directory,
    closedTransports, hostController,
    start: () => runner.emit({ type: "session_start", reason: "startup" }),
    shutdown: () => runner.emit({ type: "session_shutdown", reason: "quit" }),
    names: () => runner.getAllRegisteredTools().map(tool => tool.definition.name),
    expire() { assert.ok(expire); expire!(); },
    revoke() { admitted = false; },
    imported: () => imported,
    parentAborted: () => parentSignal?.aborted,
    async receipt() {
      try { return JSON.parse(await readFile(join(directory, "receipts", `${journal.operationId(runId, receiptId)}.json`), "utf8")); }
      catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return undefined; throw error; }
    },
    invoke(id = "operation") {
      const tool = runner.getToolDefinition("synthetic_charge");
      assert.ok(tool);
      return tool.execute(id, {}, undefined, undefined, runner.createContext());
    },
    released: () => released,
  };
}

type Fixture = Awaited<ReturnType<typeof fixture>>;
async function scenario(name: string, config: Parameters<typeof fixture>[1], run: (f: Fixture) => Promise<unknown>) {
  const f = await fixture(name, config);
  try {
    const evidence = await run(f);
    results.push({ name, evidence });
    process.stdout.write(`PASS lifecycle:${name}\n`);
  } finally {
    f.paused.release(); f.cancelDelivery.release(); f.transportClose.release();
    await f.adapter.close();
    await f.adapter.cleanup;
    assert.equal(f.adapter.snapshot().phase, "closed");
    assert.equal(f.adapter.snapshot().pending, 0);
  }
}
try {
  await scenario("startup-barrier", { stage: "discovery" }, async f => {
    const started = f.start();
    await f.paused.entered;
    assert.equal(f.adapter.snapshot().phase, "starting");
    assert.deepEqual(f.names(), []);
    f.paused.release(); await started; await f.adapter.ready();
    assert.deepEqual(f.names(), ["synthetic_charge"]);
    assert.deepEqual(f.runner.getRegisteredCommands(), []);
    assert.equal(f.runner.getFlags().size, 0);
    assert.equal(f.errors.length, 0);
    await f.invoke(); assert.equal((await f.receipt())?.state, "succeeded");
    await f.shutdown();
    assert.deepEqual(f.adapter.snapshot(), { phase: "closed", pending: 0, connections: [], retainedGrant: false, retainedMetadata: 0 });
    return { registered: f.names(), commands: [], flags: [], trace: f.trace, closed: f.adapter.snapshot() };
  });
  await scenario("close-before-start", {}, async f => {
    await f.adapter.close(); await f.start(); await assert.rejects(f.adapter.ready());
    assert.deepEqual(f.wire, []); assert.deepEqual(f.names(), []);
    return { protocol: f.wire, phase: f.adapter.snapshot().phase };
  });
  await scenario("missing-grant", { admitted: false }, async f => {
    await f.start(); await assert.rejects(f.adapter.ready());
    assert.deepEqual(f.wire, []); assert.deepEqual(f.names(), []);
    assert.equal(f.adapter.snapshot().phase, "closed");
    return { protocol: f.wire, errors: f.errors };
  });
  for (const stage of ["factory", "handshake", "discovery"]) {
    await scenario(`close-during-${stage}`, { stage }, async f => {
      const started = f.start(); await f.paused.entered;
      const closing = f.adapter.close();
      assert.equal(f.adapter.snapshot().phase, "closing"); assert.ok(f.released());
      await assert.rejects(f.adapter.ready());
      f.paused.release(); await started;
      assert.deepEqual(await closing, { status: "closed", cleanupFailed: false });
      assert.deepEqual(f.names(), []); assert.deepEqual(f.adapter.snapshot().connections, []);
      assert.ok(f.closedTransports.has("synthetic"));
      if (stage === "factory") assert.deepEqual(f.wire, []);
      return { protocol: f.wire, latePublication: false, closed: f.adapter.snapshot() };
    });
  }
  await scenario("late-factory-cleanup-fails", { stage: "factory", closeFails: true }, async f => {
    const started = f.start(); await f.paused.entered;
    const close = f.adapter.close(); f.paused.release(); await started;
    assert.deepEqual(await close, { status: "closed", cleanupFailed: true });
    await assert.rejects(f.adapter.ready()); assert.deepEqual(f.wire, []); assert.deepEqual(f.names(), []);
    return { cleanupFailed: true, protocol: [], registered: [] };
  });
  await scenario("restart-during-discovery", { stage: "discovery" }, async f => {
    const first = f.start(); await f.paused.entered;
    const second = f.start();
    assert.equal(f.adapter.snapshot().phase, "closing");
    f.paused.release(); await Promise.all([first, second]);
    await assert.rejects(f.adapter.ready()); assert.deepEqual(f.names(), []);
    assert.equal(f.wire.filter(item => item.method === "initialize").length, 1);
    return { registered: [], initializationResent: false, closed: f.adapter.snapshot() };
  });
  await scenario("revoked-during-discovery", { stage: "discovery" }, async f => {
    const started = f.start(); await f.paused.entered; f.revoke(); f.paused.release(); await started;
    await assert.rejects(f.adapter.ready()); assert.deepEqual(f.names(), []);
    return { closed: f.adapter.snapshot(), registered: f.names() };
  });
  await scenario("failed-discovery", { failedServer: "synthetic" }, async f => {
    await f.start(); await assert.rejects(f.adapter.ready()); assert.deepEqual(f.names(), []);
    assert.ok(f.closedTransports.has("synthetic"));
    return { registered: f.names(), errors: f.errors, trace: f.trace };
  });
  await scenario("partial-discovery-failure", { servers: ["synthetic", "broken"], failedServer: "broken" }, async f => {
    await f.start(); await assert.rejects(f.adapter.ready()); assert.deepEqual(f.names(), []);
    assert.deepEqual([...f.closedTransports].sort(), ["broken", "synthetic"]);
    return { registered: f.names(), closed: f.adapter.snapshot() };
  });
  await scenario("close-pending-approval", { stage: "approval" }, async f => {
    await f.start(); await f.adapter.ready();
    const work = f.invoke(); await f.paused.entered;
    const close = f.adapter.close(); f.paused.release(); await work; await close;
    assert.equal(await f.receipt(), undefined);
    assert.ok(!f.wire.some(item => item.method === "tools/call"));
    return { dispatched: false, phase: f.adapter.snapshot().phase };
  });
  await scenario("close-dispatched-call", { stage: "call" }, async f => {
    await f.start(); await f.adapter.ready();
    const work = f.invoke(); await f.paused.entered;
    f.hostController.abort(); await work; const closed = await f.adapter.close();
    assert.equal((await f.receipt())?.state, "outcome_unknown");
    assert.equal(f.wire.filter(item => item.method === "tools/call").length, 1);
    assert.ok(f.wire.some(item => item.method === "notifications/cancelled"));
    const previous = structuredClone(f.wire); await f.invoke("late"); assert.deepEqual(f.wire, previous);
    return { closed, receipt: "outcome_unknown", wire: f.wire };
  });
  await scenario("cancel-delivery-stalls", { stage: "cancel-delivery" }, async f => {
    await f.start(); await f.adapter.ready();
    const work = f.invoke(); await f.paused.entered;
    const close = f.adapter.close(); await f.cancelDelivery.entered; await work;
    await f.deadlineArmed.promise; f.expire();
    assert.equal((await close).status, "incomplete");
    assert.equal((await f.receipt())?.state, "outcome_unknown");
    assert.equal(f.adapter.snapshot().phase, "closing");
    const previous = structuredClone(f.wire); await f.invoke("late"); assert.deepEqual(f.wire, previous);
    f.cancelDelivery.release(); await f.adapter.cleanup;
    assert.equal(f.adapter.snapshot().phase, "closed");
    return { deadlineResult: "incomplete", receipt: "outcome_unknown", lateDispatch: false, wire: f.wire };
  });
  await scenario("close-during-import", { stage: "import" }, async f => {
    await f.start(); await f.adapter.ready();
    const work = f.invoke(); await f.paused.entered;
    assert.equal((await f.receipt())?.state, "dispatched");
    const close = f.adapter.close(); assert.ok(f.parentAborted());
    f.expire(); assert.equal((await close).status, "incomplete");
    assert.equal((await f.receipt())?.state, "dispatched");
    f.paused.release(); await work;
    assert.equal((await f.receipt())?.state, "outcome_unknown"); assert.equal(f.imported(), false);
    return { afterDeadline: "dispatched", afterDrain: "outcome_unknown", imported: false };
  });
  await scenario("transport-close-stalls", { stage: "close" }, async f => {
    await f.start(); await f.adapter.ready();
    const close = f.adapter.close(); assert.equal(f.adapter.close(), close); await f.transportClose.entered; f.expire();
    assert.deepEqual(await close, { status: "incomplete", cleanupFailed: false });
    assert.ok(f.released()); assert.deepEqual(f.adapter.snapshot().connections, []);
    f.transportClose.release(); await f.adapter.cleanup;
    assert.equal(f.adapter.snapshot().phase, "closed");
    return { deadlineResult: "incomplete", grantsReleased: true, routesRemoved: true };
  });
  await scenario("shutdown-hook-incomplete", { stage: "close" }, async f => {
    await f.start(); await f.adapter.ready();
    const shutdown = f.shutdown(); await f.transportClose.entered; f.expire(); await shutdown;
    assert.deepEqual(f.errors, [{ event: "session_shutdown", error: "prototype_cleanup_incomplete" }]);
    assert.equal((await f.adapter.close()).status, "incomplete"); await assert.rejects(f.adapter.ready());
    f.transportClose.release(); await f.adapter.cleanup;
    return { shutdownError: "prototype_cleanup_incomplete", lateCleanup: f.adapter.snapshot() };
  });
  await scenario("transport-close-fails", { closeFails: true }, async f => {
    await f.start(); await f.adapter.ready();
    await f.shutdown();
    const result = await f.adapter.close();
    assert.deepEqual(result, { status: "closed", cleanupFailed: true });
    assert.deepEqual(f.errors, [{ event: "session_shutdown", error: "prototype_cleanup_incomplete" }]);
    assert.deepEqual(f.adapter.snapshot().connections, []);
    return { result, closed: f.adapter.snapshot() };
  });
  await scenario("cancel-delivery-fails", { stage: "call", cancelFails: true }, async f => {
    await f.start(); await f.adapter.ready();
    const work = f.invoke(); await f.paused.entered;
    const close = f.adapter.close(); await work;
    assert.deepEqual(await close, { status: "closed", cleanupFailed: true });
    assert.equal((await f.receipt())?.state, "outcome_unknown");
    return { cancellationDelivered: false, receipt: "outcome_unknown", cleanupFailed: true };
  });
  await scenario("registration-collision", { collision: true }, async f => {
    await f.start(); await assert.rejects(f.adapter.ready());
    assert.deepEqual(f.names(), ["synthetic_charge"]);
    const tool = f.runner.getToolDefinition("synthetic_charge"); assert.equal(tool?.description, "Reserved fixture tool");
    assert.ok(!f.wire.some(item => item.method === "tools/call"));
    return { existingToolPreserved: true, hostedReady: false, phase: f.adapter.snapshot().phase };
  });
  await scenario("registration-fails", { registerFails: true }, async f => {
    await f.start(); await assert.rejects(f.adapter.ready()); assert.deepEqual(f.names(), []);
    assert.equal(f.adapter.snapshot().phase, "closed");
    return { registered: [], errors: f.errors, closed: f.adapter.snapshot() };
  });
  await scenario("fresh-instance-same-server", {}, async f => {
    await f.start(); await f.adapter.ready(); await f.invoke("old-operation"); await f.adapter.close();
    await assert.rejects(f.adapter.ready());
    const next = await fixture("fresh-instance-successor");
    try {
      await next.start(); await next.adapter.ready();
      const oldWire = structuredClone(f.wire); await f.invoke("retired-operation"); assert.deepEqual(f.wire, oldWire);
      await next.invoke("new-operation"); assert.equal((await next.receipt())?.state, "succeeded");
      assert.equal((await f.receipt())?.authorization.toolCallId, "old-operation");
      assert.notEqual((await f.receipt())?.authorization.runtimeEpoch, (await next.receipt())?.authorization.runtimeEpoch);
      return { oldInstanceRetired: true, newInstanceAdmitted: true, oldWire, newWire: next.wire };
    } finally { await next.adapter.close(); await next.adapter.cleanup; }
  });
  await scenario("retired-instance-restart", {}, async f => {
    await f.start(); await f.adapter.ready(); await f.shutdown();
    const previous = structuredClone(f.wire); await f.start(); await f.invoke("late");
    assert.deepEqual(f.wire, previous); assert.equal(f.adapter.snapshot().phase, "closed");
    return { newConnection: false, lateDispatch: false, errors: f.errors };
  });
  assert.ok(!inspect([...results, diagnostics], { depth: null }).includes("synthetic-lifecycle-credential"));
  assert.equal(unexpectedNetwork, false);
  await writeFile(join(root, "report.json"), JSON.stringify({ status: "passed", adapter: "3.1.0", pi: "0.85.1", results,
    canaryInDiagnostics: false, unexpectedNetwork: false }, null, 2));
  await writeFile(join(import.meta.dirname, "latest-lifecycle-report-path.txt"), join(root, "report.json")+"\n");
  process.stdout.write(`REPORT ${join(root, "report.json")}\n`);
} finally { console.error = originalError; }
