export type BrowserTaskApproval = { kind: 'browse_task'; sites: string[] };
