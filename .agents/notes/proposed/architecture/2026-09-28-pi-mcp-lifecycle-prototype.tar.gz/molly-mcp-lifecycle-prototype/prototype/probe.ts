import assert from "node:assert/strict";
import { createHash, randomUUID } from "node:crypto";
import { EventEmitter } from "node:events";
import { tmpdir } from "node:os";
import { logger } from "../logger.ts";
import { mkdtemp, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { join } from "node:path";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/client";
import { McpServerManager } from "../server-manager.ts";
import { createDirectToolExecutor } from "../direct-tools.ts";
import { withSessionRecovery } from "../session-recovery.ts";
import type { McpExtensionState } from "../state.ts";
import type { PrototypeOperation, PrototypeResourceRead } from "../prototype-hosted.ts";
import { MCP_TOOL_APPROVAL_REQUEST_EVENT, type McpToolApprovalRequest } from "../types.ts";
import { ToolOperationJournal } from "./molly/tool-operation-journal.ts";
import { resolveMcpContent } from "./molly/mcp-content.ts";
import { createBoundModelFetch } from "./molly/model-transport.ts";

const root = await mkdtemp(join(import.meta.dirname, "PROTOTYPE-run-"));
const png = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jBz0AAAAASUVORK5CYII=";
const sha = createHash("sha256").update(Buffer.from(png, "base64")).digest("hex");
const results: Array<{ name: string; evidence: unknown }> = [];
const diagnostics: unknown[] = [];
logger.setLevel("debug");
logger.addHandler(({ timestamp, ...entry }) => { diagnostics.push(entry); });
const watchdog = setTimeout(() => { process.stderr.write("PROTOTYPE probe failed to settle\n"); process.exit(1); }, 30_000);
watchdog.unref();
const clone = <T>(value: T): T => structuredClone(value);
const schema = { type: "object", properties: { prompt: { type: "string" } }, required: ["prompt"] };

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}

async function host(name: string, admitted = true) {
  const directory = join(root, name);
  await mkdir(directory);
  const journal = new ToolOperationJournal(join(directory, "receipts"));
  const runId = createHash("sha256").update(name).digest("hex");
  const epoch = randomUUID();
  const controller = new AbortController();
  const endpoint = `https://${name}.prototype.invalid/mcp`;
  const canary = `synthetic-credential-${name}`;
  let grant = admitted ? { runId, epoch, server: name, revision: 1, endpoint } : undefined;
  let catalog = clone(schema);
  let live = true;
  let failedOnce = false;
  let session = 0;
  let mode = "success";
  let expectedReceipt: string | undefined;
  let rawSeen: unknown;
  let savedReader: PrototypeResourceRead | undefined;
  let approval: (request: McpToolApprovalRequest) => Promise<"allow_once" | "deny"> = async () => "allow_once";
  const trace: string[] = [];
  const requests: string[] = [];
  const initCapabilities: unknown[] = [];
  const wireOperations: Array<{ method: string; session: string | null; receipt: string }> = [];
  const pauseCall = deferred<void>();
  const callEntered = deferred<void>();
  const importEntered = deferred<void>();
  const pauseImport = deferred<void>();
  const invalidated = deferred<void>();
  let stream: ReadableStreamDefaultController<Uint8Array> | undefined;
  let notifyEnabled = false;
  const json = (id: unknown, result: unknown, headers = {}) => new Response(JSON.stringify({ jsonrpc: "2.0", id, result }),
    { status: 200, headers: { "content-type": "application/json", ...headers } });
  const fixtureFetch: typeof fetch = async (input, init) => {
    const request = new Request(input, init);
    assert.equal(request.url, endpoint);
    assert.equal(request.headers.get("x-prototype-key"), canary);
    assert.equal(request.redirect, "error");
    if (request.method === "GET") {
      if (!notifyEnabled) return new Response(null, { status: 405 });
      return new Response(new ReadableStream<Uint8Array>({ start(c) { stream = c; }, cancel() { stream = undefined; } }),
        { headers: { "content-type": "text/event-stream" } });
    }
    if (request.method === "DELETE") return new Response(null, { status: 202 });
    const message = JSON.parse(await request.text());
    requests.push(message.method);
    if (message.method === "initialize") {
      session++;
      initCapabilities.push(message.params.capabilities);
      return json(message.id, { protocolVersion: "2025-06-18", serverInfo: { name: "synthetic", version: "1" },
        capabilities: { tools: { listChanged: true }, resources: {} } }, { "mcp-session-id": `session-${session}` });
    }
    if (message.method === "tools/list") return json(message.id, { tools: [{ name: "charge", description: "Synthetic image operation", inputSchema: catalog }] });
    if (message.method === "resources/list") return json(message.id, { resources: [] });
    if (message.method.startsWith("notifications/")) {
      trace.push(message.method);
      return new Response(null, { status: 202 });
    }
    if (message.method === "tools/call" || message.method === "resources/read") {
      if (mode !== "stock-replay") {
        assert.ok(expectedReceipt, "host must choose a durable receipt before protocol dispatch");
        const file = join(directory, "receipts", `${journal.operationId(runId, expectedReceipt!)}.json`);
        const receipt = JSON.parse(await readFile(file, "utf8"));
        assert.equal(receipt.state, "dispatched");
        assert.equal(receipt.authorization.runtimeEpoch, epoch);
      }
      wireOperations.push({ method: message.method, session: request.headers.get("mcp-session-id"), receipt: expectedReceipt ?? "stock-control" });
      trace.push(message.method);
      if ((mode === "expiry" || mode === "stock-replay") && !failedOnce) {
        failedOnce = true;
        return new Response("expired", { status: 404 });
      }
      if (mode === "transport-error") throw new Error(`secret diagnostic ${canary}`);
      if (mode === "lost-response") throw new Error("synthetic connection dropped after delivery");
      if (message.method === "resources/read") {
        return json(message.id, { contents: [{ uri: mode === "uri-mismatch" ? "mcp://wrong" : message.params.uri,
          mimeType: "image/png", blob: png }] });
      }
      if (mode === "cancel") {
        callEntered.resolve();
        await new Promise<void>((resolve, reject) => {
          if (request.signal.aborted) reject(new Error(canary));
          else request.signal.addEventListener("abort", () => reject(new Error(canary)), { once: true });
          pauseCall.promise.then(resolve);
        });
      }
      if (mode === "server-error") return json(message.id, { isError: true, content: [{ type: "text", text: "synthetic tool refusal" }] });
      if (["image", "image-hold", "resource-deny", "uri-mismatch"].includes(mode)) return json(message.id, {
        content: [{ type: "resource_link", name: "generated", uri: "mcp://synthetic/image", mimeType: "image/png" }],
        structuredContent: { preserved: true }, _meta: { mollyImageOperation: { state: "succeeded", assetDigests: ["f".repeat(64)] } },
      });
      return json(message.id, { content: [{ type: "text", text: "synthetic success" }], structuredContent: { preserved: true }, _meta: { privateReceipt: "synthetic" } });
    }
    throw new Error(`unexpected synthetic method ${message.method}`);
  };
  const guardedFetch = createBoundModelFetch(endpoint, fixtureFetch);
  const manager = new McpServerManager(directory, {
    async create(server, signal) {
      signal?.throwIfAborted();
      assert.deepEqual(grant, { runId, epoch, server, revision: 1, endpoint });
      trace.push("grant-validated");
      return new StreamableHTTPClientTransport(new URL(endpoint), { fetch: guardedFetch,
        requestInit: { headers: { "x-prototype-key": canary } }, reconnectionOptions: { maxRetries: 0, initialReconnectionDelay: 1, maxReconnectionDelay: 1, reconnectionDelayGrowFactor: 1 } });
    },
    toolsChanged() { live = false; invalidated.resolve(); },
  });
  manager.setRuntimeSignal(controller.signal);
  const definition = { command: "PROTOTYPE-supplied-transport", auth: false as const, oauth: false as const, tasks: false, protocolVersion: "legacy" as const };
  const bus = new EventEmitter();
  bus.on(MCP_TOOL_APPROVAL_REQUEST_EVENT, (request: McpToolApprovalRequest) => {
    assert.ok(!JSON.stringify(request.args).includes(canary));
    request.claim(async () => {
      trace.push(`approval:${request.origin}`);
      return await approval(request);
    });
  });
  const state = {
    manager, config: { settings: { approveTools: true, autoAuth: false, sampling: false, elicitation: false, scriptMode: false,
      allowInstall: false, namespaceProxyTools: false, exposeResources: false, jev: false }, mcpServers: { [name]: definition } },
    toolMetadata: new Map(), approvalEvents: bus, approvedToolCalls: new Map(), approvedServers: new Map(),
    completedUiSessions: [], failureTracker: new Map(), failureMessages: new Map(),
    prototypeHost: {
      signal: controller.signal,
      available: () => live && grant?.epoch === epoch,
      async dispatch(operation: PrototypeOperation, send: () => Promise<unknown>, read: PrototypeResourceRead) {
        expectedReceipt = operation.toolCallId;
        savedReader = read;
        const image = ["image", "image-hold", "resource-deny", "uri-mismatch"].includes(mode);
        return await journal.dispatch({ snapshot: { runId, runtimeEpoch: epoch }, connectionId: `workspace:${name}`, connectionRevision: 1,
          toolCallId: operation.toolCallId, toolName: operation.toolName, arguments: operation.args, externalImage: image,
          ...(image ? { importImages: async (result: unknown) => {
            trace.push("host-import-entered");
            importEntered.resolve();
            if (mode === "image-hold") await pauseImport.promise;
            const raw = result as { content: Array<{ type: string; data?: string }> };
            assert.equal(raw.content.find(part => part.type === "image")?.data, png);
            const absolutePath = join(directory, "media", `${sha}.png`);
            await mkdir(join(directory, "media"), { recursive: true });
            await writeFile(absolutePath, Buffer.from(png, "base64"));
            trace.push("host-import-completed");
            return { assets: [{ sha256: sha, path: `media/${sha}.png`, absolutePath, mimeType: "image/png" as const,
              bytes: Buffer.from(png, "base64").length, width: 1, height: 1 }] };
          } } : {}),
        }, async context => {
          const raw = await send();
          if (mode === "double-continuation") await send();
          rawSeen = clone(raw);
          if (!image) return raw;
          const content = await resolveMcpContent(raw, (uri, index) => read(uri, `${operation.toolCallId}:resource:${index}`, async (child, dispatch) => {
            assert.equal(child.connectionIdentity, operation.connectionIdentity);
            assert.equal(child.parentToolCallId, operation.toolCallId);
            expectedReceipt = child.toolCallId;
            return await context!.readResource!(child.toolCallId, uri, dispatch);
          }));
          return { ...(raw as object), content };
        });
      },
    },
  } as unknown as McpExtensionState;
  const execute = createDirectToolExecutor(() => state, () => null, {
    serverName: name, originalName: "charge", prefixedName: `${name}_charge`, description: "Synthetic image operation", inputSchema: clone(schema),
  });
  return {
    directory, journal, runId, epoch, trace, wireOperations, requests, manager, state, controller,
    callEntered, importEntered, pauseImport, initCapabilities, invalidated,
    mode(value: string) { mode = value; },
    approve(fn: typeof approval) { approval = fn; },
    mutateCatalog() { catalog = { ...catalog, required: ["changed"] }; },
    revoke() { live = false; grant = undefined; },
    wrongGrant() { grant = { runId, epoch: randomUUID(), server: name, revision: 1, endpoint }; },
    forbiddenDestination() { return guardedFetch("https://different.prototype.invalid/mcp", { headers: { "x-prototype-key": canary } }); },
    enableNotifications() { notifyEnabled = true; },
    notify() { assert.ok(stream); stream!.enqueue(new TextEncoder().encode('event: message\ndata: {"jsonrpc":"2.0","method":"notifications/tools/list_changed"}\n\n')); },
    async ready() {
      const connection = await manager.connect(name, definition);
      state.toolMetadata.set(name, connection.tools.map(tool => ({ name: `${name}_${tool.name}`, originalName: tool.name,
        description: tool.description ?? "", ...(tool.inputSchema ? { inputSchema: tool.inputSchema } : {}) })));
      return connection;
    },
    async invoke(id: string, signal?: AbortSignal) { return await execute(id, { prompt: "synthetic input" }, signal, undefined, undefined as never); },
    raw() { return rawSeen; },
    reader() { return savedReader!; },
    receipt(id: string) { return journal.read(journal.operationId(runId, id)); },
    async close() { controller.abort(); stream?.close(); stream = undefined; await manager.closeAll(); grant = undefined; live = false; },
  };
}

async function scenario(name: string, run: (h: Awaited<ReturnType<typeof host>>) => Promise<unknown>, admitted = true) {
  const h = await host(name, admitted);
  try {
    const evidence = await run(h);
    results.push({ name, evidence });
    process.stdout.write(`PASS ${name}\n`);
  } finally { await h.close(); }
}

try {
  await scenario("ungranted", async h => {
    await assert.rejects(h.ready());
    assert.deepEqual(h.requests, []);
    return { protocolRequests: h.requests };
  }, false);
  await scenario("stock-replay", async h => {
    h.mode("stock-replay");
    await h.ready();
    const result = await withSessionRecovery({ manager: h.manager, config: h.state.config }, "stock-replay",
      conn => conn.client.callTool({ name: "charge", arguments: { prompt: "synthetic control" } }));
    assert.deepEqual(h.wireOperations.map(op => op.session), ["session-1", "session-2"]);
    assert.ok(result.content);
    return { control: "unmodified recovery callback resends after expiry", wire: h.wireOperations };
  });
  await scenario("success", async h => {
    await h.ready();
    const result = await h.invoke("call-success");
    assert.equal((await h.receipt("call-success")).state, "succeeded");
    assert.deepEqual(h.raw(), { content: [{ type: "text", text: "synthetic success" }], structuredContent: { preserved: true }, _meta: { privateReceipt: "synthetic" } });
    assert.ok(JSON.stringify(result).includes("synthetic success"));
    assert.deepEqual(h.initCapabilities, [{}]);
    return { state: "succeeded", wire: h.wireOperations, rawResultPreserved: true, clientCapabilities: h.initCapabilities };
  });
  for (const failure of ["expiry", "lost-response", "transport-error"]) {
    await scenario(failure, async h => {
      h.mode(failure);
      await h.ready();
      const result = await h.invoke("call-lost");
      assert.equal((await h.receipt("call-lost")).state, "outcome_unknown");
      await h.invoke("call-lost");
      assert.deepEqual(h.wireOperations.map(op => op.method), ["tools/call"]);
      const reopened = new ToolOperationJournal(join(h.directory, "receipts"));
      assert.equal((await reopened.read(reopened.operationId(h.runId, "call-lost"))).state, "outcome_unknown");
      await assert.rejects(reopened.dispatch({ snapshot: { runId: h.runId, runtimeEpoch: h.epoch }, connectionId: `workspace:${failure}`,
        connectionRevision: 1, toolCallId: "call-lost", toolName: "charge", arguments: { prompt: "synthetic input" } },
        async () => { throw new Error("REPLAY_WOULD_HAVE_EXECUTED"); }), /EEXIST/);
      assert.ok(!JSON.stringify(result).includes(`synthetic-credential-${failure}`));
      return { recovered: "outcome_unknown", wire: h.wireOperations, modelResult: result };
    });
  }
  await scenario("wrong-epoch", async h => {
    h.wrongGrant(); await assert.rejects(h.ready()); assert.deepEqual(h.requests, []);
    return { wrongEpoch: "rejected before transport" };
  });
  await scenario("destination", async h => {
    await h.ready(); const before = clone(h.requests);
    await assert.rejects(h.forbiddenDestination(), /destination_changed/);
    assert.deepEqual(h.requests, before);
    return { otherOrigin: "rejected before supplied fetch" };
  });
  await scenario("double-continuation", async h => {
    h.mode("double-continuation"); await h.ready(); await h.invoke("once");
    assert.deepEqual(h.wireOperations.map(op => op.method), ["tools/call"]);
    assert.equal((await h.receipt("once")).state, "outcome_unknown");
    return { wire: h.wireOperations, reusedContinuation: "rejected" };
  });
  await scenario("new-operation", async h => {
    h.mode("lost-response"); await h.ready(); await h.invoke("old");
    h.mode("success"); await h.invoke("new");
    assert.equal((await h.receipt("old")).state, "outcome_unknown");
    assert.equal((await h.receipt("new")).state, "succeeded");
    assert.deepEqual(h.wireOperations.map(op => op.receipt), ["old", "new"]);
    return { old: "outcome_unknown", new: "succeeded", wire: h.wireOperations };
  });
  await scenario("approval-cancel", async h => {
    await h.ready(); const entered = deferred<void>(); const finish = deferred<"allow_once">();
    h.approve(async () => { entered.resolve(); return await finish.promise; });
    const cancellation = new AbortController();
    const pending = h.invoke("approval-pending", cancellation.signal);
    await entered.promise; cancellation.abort(); await pending; finish.resolve("allow_once");
    assert.deepEqual(h.wireOperations, []); await assert.rejects(h.receipt("approval-pending"));
    return { lateApproval: "no dispatch", wire: h.wireOperations };
  });
  await scenario("notification", async h => {
    h.enableNotifications(); await h.ready(); h.notify(); await h.invalidated.promise;
    await h.invoke("changed-notification"); assert.deepEqual(h.wireOperations, []);
    return { listChanged: "connection fenced", wire: h.wireOperations };
  });
  await scenario("denied", async h => {
    await h.ready(); h.approve(async () => "deny");
    await h.invoke("denied");
    assert.deepEqual(h.wireOperations, []);
    await assert.rejects(h.receipt("denied"));
    return { wire: h.wireOperations, receipt: "absent" };
  });
  await scenario("schema-change", async h => {
    await h.ready();
    h.approve(async () => { h.mutateCatalog(); return "allow_once"; });
    await h.invoke("changed");
    assert.deepEqual(h.wireOperations, []);
    return { schemaChangedDuringApproval: true, wire: h.wireOperations };
  });
  await scenario("revocation", async h => {
    await h.ready();
    h.approve(async () => { h.revoke(); return "allow_once"; });
    await h.invoke("revoked");
    assert.deepEqual(h.wireOperations, []);
    return { revokedDuringApproval: true, wire: h.wireOperations };
  });
  await scenario("server-error", async h => {
    h.mode("server-error"); await h.ready();
    const result = await h.invoke("rejected");
    assert.equal((await h.receipt("rejected")).state, "failed");
    assert.ok(JSON.stringify(result).includes("synthetic tool refusal"));
    return { state: "failed", modelResult: result };
  });
  await scenario("image", async h => {
    h.mode("image-hold"); await h.ready();
    const pending = h.invoke("image-parent");
    await h.importEntered.promise;
    const onDisk = JSON.parse(await readFile(join(h.directory, "receipts", `${h.journal.operationId(h.runId, "image-parent")}.json`), "utf8"));
    assert.equal(onDisk.state, "dispatched");
    assert.equal((await h.receipt("image-parent:resource:0")).state, "succeeded");
    h.pauseImport.resolve();
    const result = await pending;
    const receipt = await h.receipt("image-parent");
    assert.equal(receipt.state, "succeeded");
    assert.deepEqual(receipt.assetDigests, [sha]);
    assert.ok(!JSON.stringify(result).includes("f".repeat(64)));
    assert.ok(!JSON.stringify(result).includes(png));
    await assert.rejects(h.reader()("mcp://synthetic/image", "late-child", async (_op, send) => send()));
    assert.deepEqual(h.wireOperations.map(op => op.method), ["tools/call", "resources/read"]);
    return { parentStayedDispatchedDuringImport: true, assetDigests: receipt.assetDigests, lateRead: "rejected", wire: h.wireOperations, trace: h.trace };
  });
  for (const failure of ["resource-deny", "uri-mismatch"]) {
    await scenario(failure, async h => {
      h.mode(failure); await h.ready();
      if (failure === "resource-deny") h.approve(async request => request.origin === "resource" ? "deny" : "allow_once");
      await h.invoke("image-parent");
      const receipt = await h.receipt("image-parent");
      assert.equal(receipt.state, "outcome_unknown");
      assert.deepEqual(receipt.assetDigests, []);
      assert.ok(!h.trace.includes("host-import-entered"));
      return { parent: receipt.state, wire: h.wireOperations, imported: false };
    });
  }
  await scenario("cancel", async h => {
    h.mode("cancel"); await h.ready();
    const cancellation = new AbortController();
    const pending = h.invoke("cancelled", cancellation.signal);
    await h.callEntered.promise;
    cancellation.abort();
    const result = await pending;
    assert.equal((await h.receipt("cancelled")).state, "outcome_unknown");
    assert.ok(!JSON.stringify(result).includes("synthetic-credential-cancel"));
    assert.deepEqual(h.wireOperations.map(op => op.method), ["tools/call"]);
    return { state: "outcome_unknown", wire: h.wireOperations, trace: h.trace };
  });
  await scenario("settled-lifetime", async h => {
    await h.ready(); await h.close();
    await h.invoke("after-close");
    await assert.rejects(h.ready());
    assert.deepEqual(h.wireOperations, []);
    return { afterClose: "no dispatch or reconnect" };
  });
  assert.ok(!JSON.stringify(diagnostics).includes("synthetic-credential-"));
  const automaticOutput = (await readdir(tmpdir())).filter(name => name.startsWith("pi-mcp-output-") || name.startsWith("pi-mcp-resource-"));
  assert.deepEqual(automaticOutput, []);
  const auditFiles = async (directory: string): Promise<void> => {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) await auditFiles(path);
      else assert.ok(!(await readFile(path)).includes(Buffer.from("synthetic-credential-")), `credential canary persisted at ${entry.name}`);
    }
  };
  await auditFiles(root);
  const loadedNative = Object.keys(createRequire(import.meta.url).cache).filter(path => path.includes("@napi-rs/keyring"));
  assert.deepEqual(loadedNative, []);
  await writeFile(join(root, "report.json"), JSON.stringify({ status: "passed", adapter: "3.1.0", pi: "0.85.1", results, nativeKeyringModules: loadedNative, automaticOutputFiles: automaticOutput, diagnosticCanaryFound: false, receiptAndAssetCanaryFound: false }, null, 2));
  await writeFile(join(import.meta.dirname, "latest-report-path.txt"), join(root, "report.json") + "\n");
  process.stdout.write(`REPORT ${join(root, "report.json")}\n`);
} catch (error) {
  await writeFile(join(root, "report.json"), JSON.stringify({ status: "failed", passed: results, error: String(error) }, null, 2));
  throw error;
}
