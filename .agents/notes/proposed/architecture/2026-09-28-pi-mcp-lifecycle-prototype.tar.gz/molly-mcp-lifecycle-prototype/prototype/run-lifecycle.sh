#!/bin/sh
set -eu
prototype_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
prototype_temp=$(mktemp -d "$prototype_root/prototype/PROTOTYPE-temp.XXXXXX")
cd "$prototype_root"
exec env -i PATH="$PATH" TMPDIR="$prototype_temp" PI_CODING_AGENT_DIR="$prototype_temp/agent" node --import tsx prototype/lifecycle-probe.ts
