# Released host-managed API compatibility gates

This is a local review artifact for Molly issue #41, not an adopted dependency patch.
It tests the actual published `pi-mcp-adapter/host-managed` entry in version 3.2.0,
then applies a proposed patch to that release's exact upstream commit. The earlier
3.1.0 experiments are separate historical evidence.

Run `python3 reproduce.py` with Python 3.9+, Git, npm and Node 22.14+.
Setup downloads two checksum-verified upstream archives and runs a locked npm install
inside a fresh temporary directory. The harness pins Pi to Molly's 0.85.1 and TypeBox
to 1.3.7. npm lifecycle scripts are disabled. No installed dependency tree, real
credentials, user configuration or captured conversation is included.

The first test phase is expected to fail exactly 11 of 14 assertions against the
unmodified npm package. The script verifies those counts before continuing. The
patched phase must pass all 312 tests across nine suites and the upstream TypeScript
check. Detailed logs and JSON results remain in the new temporary directory. The
focused fixtures use injected HTTP responses and deferred gates/fake timers; they
make no external MCP or provider calls.

`upstream-host-managed.patch` contains the proposed implementation, upstream contract
documentation, two existing lifecycle expectation updates, and 17 focused cases.
`manifest.json` records source/archive hashes and expected outcomes. The upstream
MIT license is in `UPSTREAM-LICENSE`. Nothing here authorizes publishing a PR or
replacing Molly's production bridge.

The remaining work includes actual Molly AgentSession/journal integration, owning-host
image import, grant/history rebuild, transport/protocol acceptance and sealed
CLI/Electron packaging. Passing these narrow tests does not establish those gates.
