# Proposed upstream fixes

Version 3.2.0 supplies the supported host-managed entry requested in upstream #716.
Testing found several differences from Molly's existing contract. This local patch
preserves the ordinary extension and targets the separate host-managed module.

- Preserve the complete input schema when registering tools. The prior normalization
  removed `$schema` and `additionalProperties`, despite supplying the original schema
  to the host callback.
- Reject duplicate tool names and cursor cycles. SDK 2.0.0 aggregates pages but silently
  stops on a repeated cursor, accepting a partial catalog. The patch uses the SDK's
  public typed request method per page so the adapter can reject that condition. It
  retains a 64-page bound. This is a deliberate departure from relying on `listTools`;
  an equivalent upstream SDK fail-closed option would be preferable if available.
- Add opt-in `revalidateCatalog` for hosts needing checks without server notifications.
  It adds complete catalog reads before approval, host execution and dispatch, comparing
  the entire descriptor. The ordinary call path retains notification-based checks.
  The additional reads are a known latency cost, not a measured performance improvement.
- Refuse readiness after close and suppress successful host results completed after close.
- Track pending transport factories and late disposal; reject close with fixed text if
  host work, a factory or transport cleanup outlives the five-second deadline, or cleanup
  fails. Timeout remains an incomplete outcome even if late disposal eventually succeeds.
  This changes close's contract; callers must handle rejection.

These should be separated into narrow upstream submissions if publication is authorized.
No upstream acceptance of this patch is implied. The two existing tests updated here
previously expected a successful close despite pending work; they now assert incomplete
cleanup using fake timers. Suite teardown observes all close outcomes without creating
unhandled promise rejections. No failure is hidden by weakening a production assertion.

Molly still needs supported access to complete frozen descriptors and stable custom
tool names. Sanitized `<server>_<tool>` names cannot be inverted to raw names and can
collide, while Molly's hashed identities and image bindings require exact raw identity
and schema. This artifact does not yet invent or implement that additional API.
Catalog size/time bounds and the host's cancellation-delivery window also still need
integration acceptance; the upstream five-second cleanup deadline is not automatically
equivalent to Molly's existing 30-second cancellation-delivery allowance.

Independent Codex CLI review was unavailable after the previously reported initialization
failure. It has not been retried automatically. The patch remains subject to human and
upstream review; passing tests are scoped behavioral evidence.
