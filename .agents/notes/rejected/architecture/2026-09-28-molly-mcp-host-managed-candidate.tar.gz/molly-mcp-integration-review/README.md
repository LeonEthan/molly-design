# Issue #41: isolated external MCP migration candidate

This review bundle contains a Molly migration patch and a proposed upstream correction/embedding patch. Neither patch is submitted or adopted in production. The candidate routes external servers through `pi-mcp-adapter/host-managed`; built-in `molly` servers retain the existing bridge. Production adoption requires an upstream-supported release containing the necessary behavior and host contract, followed by rerunning the affected acceptance checks against that release. A local pnpm patch does not satisfy that gate.

## Contents and provenance

- `molly-migration-candidate.patch`: 21 changed/new files against Molly `3e91e746b1426e1db8af122e6a833768ec0ba99d`, including exact dependency pins, pnpm lockfile/experimental patch, integration, deterministic tests, packaging and owning documentation.
- `upstream/upstream-host-managed.patch`: reviewable source, tests and documentation against upstream `b6e06a162d95322bb991b8b6214bb6fb10a90b7d` (`pi-mcp-adapter@3.2.0`). Its source change is exactly the host-managed change installed by the candidate's pnpm patch.
- `upstream/reproduce.py`: fresh, checksum-verified reproduction of the published failures and 319 patched tests; locked npm setup uses lifecycle scripts disabled and Pi 0.85.1.
- `verify-candidate.py`: applies the Molly patch in a new clone, verifies every changed source file against `manifest.json`, and leaves that clone for the commands below. It does not modify the source repository.
- `evidence.json`: scope, results and runtime identity. `REVIEW.md` records the decisions, failures, fixes and completion audit. Licenses are included. No dependency trees, binary app, private records or captured user/Agent conversations are included.

The earlier direct, lifecycle and 312-test released-API bundles remain historical evidence; this bundle supersedes their remaining host-integration and packaging questions, without rewriting their results.

## Reproduce upstream checks

Use Python 3.9+, Git, npm and Node 22.19+ (tested 22.22.0). Initial setup downloads the pinned public archives and locked packages; tests use synthetic peers.

```sh
python3 upstream/reproduce.py
```

Expected published result: 14 checks, 11 failed and 3 passed, no unhandled errors. Expected patched result: TypeScript passes and 319 tests pass in nine suites. Those baseline failures are intentional reproduction evidence, not a failure of the script.

## Apply and validate Molly

Use a supported native macOS arm64 build host with Node 22.22.0, Corepack/pnpm 10.20.0 and the repository's native build prerequisites. Exact source revision and file hashes are recorded in `manifest.json`.

```sh
python3 verify-candidate.py
# Or avoid fetching the Molly repository when a local clone already holds the base:
python3 verify-candidate.py --source /path/to/molly-design
```

In the fresh checkout printed by the script:

```sh
git submodule update --init packages/acp-extension-core packages/acp-extension-dsh
corepack pnpm install --frozen-lockfile
corepack pnpm --filter molly prepare:design-authoring
corepack pnpm run docs status
corepack pnpm check
corepack pnpm build
corepack pnpm run docs check
CSC_IDENTITY_AUTO_DISCOVERY=false corepack pnpm --dir apps/electron run package -- --dir --mac --arm64 -c.mac.identity=null
```

Use only the default ACP core/DSH submodules. Historical Claude/Codex/Grok/Kimi vendors are not part of this migration. The package wrapper defaults to `--publish never`; do not opt into publishing. This local package has no Developer ID signing or notarization; existing afterPack code applies its local ad-hoc Sparkle signature.

For the actual packaged runtime, from that checkout:

```sh
node apps/cli/scripts/smoke-embedded-harness.mjs \
  'apps/electron/dist/mac-arm64/Molly.app/Contents/Resources/app.asar.unpacked/resources/cli' \
  'apps/electron/dist/mac-arm64/Molly.app/Contents/Frameworks/Molly Helper.app/Contents/MacOS/Molly Helper' \
  --protected-mcp --compatible-model --question-ui --measure=1 --exercise-turns=3
```

This existing smoke needs permission to open a loopback socket and observe its owned process. It uses a disposable profile, synthetic model server and synthetic credentials. Measurement mode is required by the existing turn-exercise driver; no timing, memory or performance acceptance threshold is asserted. No paid provider, real image generation, installed UI, release upload or update-channel acceptance is claimed.

The root check passed 8,629 tests, with six existing skips; all package typechecks, lint and boundary checks passed. The pnpm-generated lockfile retains pnpm's format. Formatting the lockfile with generic Prettier would rewrite over 14,000 lines and is intentionally not part of this patch. Changed executable/config source files pass scoped Prettier; no commit is made, and the repository's full format-before-commit requirement still applies before any future commit.
