import { describe, expect, it, vi } from 'vitest';
import { EventEmitter } from 'node:events';
import { StreamableHTTPClientTransport, type Tool } from '@modelcontextprotocol/client';
import type { ExtensionAPI, ToolDefinition } from '@earendil-works/pi-coding-agent';
import { createHostManagedMcpAdapter, type HostManagedMcpToolCall } from './package/host-managed.ts';

function deferred<T = void>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}
const descriptor: Tool = { name: 'charge', description: 'Synthetic operation',
  inputSchema: { type: 'object', properties: { text: { type: 'string' } }, additionalProperties: false } };
async function fixture(options: { tools?: Tool[]; secondPage?: Tool[]; repeatedCursor?: boolean;
  approve?: () => Promise<'allow_once' | 'deny'>; host?: (call: HostManagedMcpToolCall) => Promise<any>;
  result?: unknown } = {}) {
  let catalog = structuredClone(options.tools ?? [descriptor]);
  const requests: Array<{ method: string; params?: any }> = [];
  const registrations: ToolDefinition[] = [];
  const bus = new EventEmitter();
  bus.on('pi-mcp-adapter:tool-approval-request', request => {
    request.claim(options.approve ?? (async () => 'allow_once'));
  });
  let transport!: StreamableHTTPClientTransport;
  const adapter = createHostManagedMcpAdapter({
    servers: { synthetic: { createTransport: () => {
      transport = new StreamableHTTPClientTransport(new URL('https://synthetic.invalid/mcp'), {
        reconnectionOptions: { maxRetries: 0, initialReconnectionDelay: 1, maxReconnectionDelay: 1, reconnectionDelayGrowFactor: 1 },
        fetch: async (input, init) => {
          const request = new Request(input, init);
          if (request.method === 'GET') return new Response(null, { status: 405 });
          if (request.method === 'DELETE') return new Response(null, { status: 202 });
          const message = JSON.parse(await request.text()); requests.push(message);
          let result: unknown;
          if (message.method === 'initialize') result = { protocolVersion: '2025-06-18', capabilities: { tools: { listChanged: true } }, serverInfo: { name: 'synthetic', version: '1' } };
          else if (message.method === 'tools/list') result = message.params?.cursor
            ? { tools: options.secondPage ?? [], ...(options.repeatedCursor ? { nextCursor: 'next' } : {}) }
            : { tools: catalog, ...(options.secondPage ? { nextCursor: 'next' } : {}) };
          else if (message.method === 'tools/call') result = options.result ?? { content: [{ type: 'text', text: 'synthetic success' }], structuredContent: { value: 1 } };
          else if (message.method.startsWith('notifications/')) return new Response(null, { status: 202 });
          else throw new Error('unexpected_synthetic_method');
          return new Response(JSON.stringify({ jsonrpc: '2.0', id: message.id, result }), { headers: { 'content-type': 'application/json', ...(message.method === 'initialize' ? { 'mcp-session-id': 'synthetic-session' } : {}) } });
        },
      });
      return transport;
    } } },
    onToolCall: options.host ?? (call => call.dispatch()),
  });
  const pi = new Proxy({ registerTool: (tool: ToolDefinition) => registrations.push(tool), events: bus }, {
    get(target, key) { if (!(key in target)) throw new Error(`unexpected_registration:${String(key)}`); return Reflect.get(target, key); },
  }) as unknown as ExtensionAPI;
  return { adapter, registrations, requests,
    async ready() { await adapter.ready(); adapter.extensionFactory(pi); },
    mutate(next: Tool[]) { catalog = structuredClone(next); },
    notify() { transport.onmessage?.({ jsonrpc: '2.0', method: 'notifications/tools/list_changed' }); },
    invoke() { return registrations[0]!.execute('synthetic-call', { text: 'fixture' }, undefined, undefined, undefined as never); },
  };
}

describe('Molly contract against published host-managed entry', () => {
  it('aggregates all catalog pages through the real SDK', async () => {
    const f = await fixture({ secondPage: [{ ...descriptor, name: 'second' }] });
    try { await f.ready(); expect(f.registrations.map(x => x.name)).toEqual(['synthetic_charge','synthetic_second']);
      expect(f.requests.filter(x => x.method === 'tools/list').map(x => x.params?.cursor)).toEqual([undefined, 'next']); }
    finally { await f.adapter.close(); }
  });
  it('preserves the complete input schema exposed to the model', async () => {
    const inputSchema = { ...descriptor.inputSchema, $schema: 'https://json-schema.org/draft/2020-12/schema' };
    const f = await fixture({ tools: [{ ...descriptor, inputSchema }] });
    try { await f.ready(); expect(f.registrations[0]!.parameters).toEqual(inputSchema); }
    finally { await f.adapter.close(); }
  });
  it('rejects duplicate server tool names instead of overwriting a descriptor', async () => {
    const f = await fixture({ tools: [descriptor, { ...descriptor, description: 'Conflicting descriptor' }] });
    try { await expect(f.ready()).rejects.toThrow(); }
    finally { await f.adapter.close(); }
  });
  it('refuses a cursor cycle', async () => {
    const f = await fixture({ secondPage: [{ ...descriptor, name: 'second' }], repeatedCursor: true });
    try { await expect(f.ready()).rejects.toThrow(); }
    finally { await f.adapter.close(); }
  });
  it.each(['description','inputSchema','outputSchema','annotations','title'] as const)('rechecks %s changed silently during approval', async field => {
    const approvalEntered = deferred(); const approval = deferred<'allow_once'>();
    const f = await fixture({ approve: async () => { approvalEntered.resolve(); return await approval.promise; } });
    try {
      await f.ready(); const work=f.invoke(); await approvalEntered.promise;
      const changes = { description: 'Changed', inputSchema: { type: 'object' as const, properties: { changed: { type: 'number' } } },
        outputSchema: { type: 'object' as const, properties: { value: { type: 'number' } } }, annotations: { readOnlyHint: true }, title: 'Changed' };
      f.mutate([{ ...descriptor, [field]: changes[field] }]); approval.resolve('allow_once'); await work;
      expect(f.requests.filter(x => x.method === 'tools/call')).toEqual([]);
    } finally { approval.resolve('allow_once'); await f.adapter.close(); }
  });
  it('retires a notified descriptor change before host dispatch', async () => {
    const entered = deferred(); const send = deferred();
    const f=await fixture({host: async call => { entered.resolve(); await send.promise; return await call.dispatch(); }});
    try { await f.ready(); const work=f.invoke(); await entered.promise;
      f.mutate([{...descriptor,description:'Changed'}]); f.notify(); send.resolve(); await work;
      expect(f.requests.filter(x=>x.method==='tools/call')).toEqual([]); }
    finally { send.resolve(); await f.adapter.close(); }
  });
  it('classifies output validation failure after exactly one dispatch', async () => {
    const f=await fixture({tools:[{...descriptor,outputSchema:{type:'object',required:['missing']}}]});
    try { await f.ready(); const result=await f.invoke(); expect(result.details).toMatchObject({error:'invalid_result'});
      expect(f.requests.filter(x=>x.method==='tools/call').map(x=>x.params.name)).toEqual(['charge']); }
    finally {await f.adapter.close();}
  });
  it('refuses readiness after close', async () => {
    const f=await fixture(); await f.ready(); await f.adapter.close();
    await expect(f.adapter.ready()).rejects.toThrow();
  });
  it('does not present a host result completed after close', async () => {
    const entered=deferred();const finish=deferred();
    const f=await fixture({host:async call=>{await call.dispatch();entered.resolve();await finish.promise;return {content:[{type:'text',text:'LATE_HOST_RESULT'}]};}});
    try {await f.ready();const work=f.invoke();await entered.promise;const closing=f.adapter.close();finish.resolve();
      const result=await work;await closing;expect(JSON.stringify(result)).not.toContain('LATE_HOST_RESULT');}
    finally {finish.resolve();await f.adapter.close();}
  });
  it('reports incomplete close when a host callback remains live at its deadline', async () => {
    vi.useFakeTimers(); const entered=deferred();const finish=deferred();
    const f=await fixture({host:async call=>{await call.dispatch();entered.resolve();await finish.promise;return {content:[]};}});
    try {await f.ready();const work=f.invoke();await entered.promise;
      const closing=f.adapter.close();const outcome=closing.then(()=>({error:undefined}),error=>({error}));await vi.advanceTimersByTimeAsync(5000);expect((await outcome).error).toBeInstanceOf(Error);
      finish.resolve();await work;}
    finally {finish.resolve();await f.adapter.close().catch(()=>{});vi.useRealTimers();}
  });
});
