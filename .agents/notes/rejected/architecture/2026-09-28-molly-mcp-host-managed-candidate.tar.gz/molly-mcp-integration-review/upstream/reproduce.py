#!/usr/bin/env python3
"""Reproduce published failures and the local proposed fixes in a fresh directory."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request

HERE = Path(__file__).resolve().parent
MANIFEST = json.loads((HERE / 'manifest.json').read_text())
WORK = Path(tempfile.mkdtemp(prefix='molly-hosted-release-gates-')).resolve()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unpack(kind):
    entry = MANIFEST[kind]
    archive = WORK / (kind + '.tar.gz')
    with urllib.request.urlopen(entry['url'], timeout=60) as response:
        archive.write_bytes(response.read())
    assert digest(archive) == entry['sha256'], kind + ' archive hash mismatch'
    target = WORK / kind
    target.mkdir()
    with tarfile.open(archive, 'r:gz') as source:
        for member in source.getmembers():
            path = (target / member.name).resolve()
            assert target in path.parents, 'unsafe archive path'
            assert member.isfile() or member.isdir(), 'unsupported archive entry'
        source.extractall(target)
    roots = list(target.iterdir())
    assert len(roots) == 1 and roots[0].is_dir(), 'unexpected archive layout'
    return roots[0]


def run(args, cwd, name, expected=0):
    with (WORK / (name + '.log')).open('w') as log:
        result = subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode != expected:
        raise RuntimeError(name + ' failed; inspect ' + str(WORK / (name + '.log')))


for name, expected in MANIFEST['artifactFiles'].items():
    assert digest(HERE / name) == expected, name + ' hash mismatch'

source = unpack('source')
published = unpack('published')
for name, expected in MANIFEST['upstreamFiles'].items():
    assert digest(source / name) == expected, name + ' source hash mismatch'
assert (source / 'host-managed.ts').read_bytes() == (published / 'host-managed.ts').read_bytes()

for name in ['package.json', 'package-lock.json']:
    shutil.copyfile(HERE / name, source / name)
run(['npm', 'ci', '--ignore-scripts', '--no-audit', '--no-fund'], source, 'install')
(published / 'node_modules').symlink_to(source / 'node_modules', target_is_directory=True)
baseline = published.parent
(baseline / 'node_modules').symlink_to(source / 'node_modules', target_is_directory=True)
shutil.copyfile(HERE / 'published-contract.test.ts', baseline / 'published-contract.test.ts')
(baseline / 'package.json').write_text('{"type":"module"}\n')
vitest = str(source / 'node_modules' / '.bin' / 'vitest')
run([vitest, 'run', 'published-contract.test.ts', '--reporter=json',
     '--outputFile=' + str(WORK / 'published.json')], baseline, 'published', expected=1)
baseline_report = json.loads((WORK / 'published.json').read_text())
assert baseline_report['numTotalTests'] == MANIFEST['baseline']['tests']
assert baseline_report['numFailedTests'] == MANIFEST['baseline']['failed']
assert baseline_report['numPassedTests'] == MANIFEST['baseline']['passed']
assert not baseline_report.get('unhandledErrors', []), 'baseline had unhandled errors'

run(['git', 'apply', str(HERE / 'upstream-host-managed.patch')], source, 'apply')
run([str(source / 'node_modules' / '.bin' / 'tsc'), '--noEmit'], source, 'typecheck')
suites = ['host-managed', 'host-managed-molly', 'direct-tools', 'tool-approval',
          'session-recovery', 'runtime-owner', 'server-manager-close-ownership',
          'server-manager-runtime-owner', 'index-lifecycle']
run([vitest, 'run'] + ['__tests__/' + name + '.test.ts' for name in suites] +
    ['--reporter=json', '--outputFile=' + str(WORK / 'patched.json')], source, 'patched')
patched_report = json.loads((WORK / 'patched.json').read_text())
assert patched_report['numTotalTests'] == MANIFEST['patched']['tests']
assert patched_report['numFailedTests'] == 0
assert patched_report['numPassedTests'] == MANIFEST['patched']['passed']
assert not patched_report.get('unhandledErrors', []), 'patched run had unhandled errors'

result = {'adapterVersion': MANIFEST['adapterVersion'], 'piVersion': MANIFEST['piVersion'],
          'sourceCommit': MANIFEST['sourceCommit'], 'published': MANIFEST['baseline'],
          'patched': MANIFEST['patched'], 'typecheck': 'passed'}
(WORK / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'workDirectory': str(WORK), 'result': result}, indent=2))
