#!/usr/bin/env python3
"""Apply the recorded candidate in a new clone and verify its exact source bytes."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / 'manifest.json').read_text())
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', default=manifest['mollyRepository'], help='Git URL or local repository containing the pinned Molly base')
args = parser.parse_args()
for name, expected in manifest['artifactFiles'].items():
    assert hashlib.sha256((HERE / name).read_bytes()).hexdigest() == expected, name + ' artifact mismatch'
work = Path(tempfile.mkdtemp(prefix='molly-mcp-patch-replay-')).resolve()
repo = work / 'molly'
clone = ['git', 'clone', '--no-checkout']
if Path(args.source).is_dir():
    clone.append('--shared')
else:
    clone.append('--filter=blob:none')
subprocess.run(clone + [args.source, str(repo)], check=True)
subprocess.run(['git', 'checkout', '--detach', manifest['mollyBase']], cwd=repo, check=True)
subprocess.run(['git', 'apply', '--check', str(HERE / 'molly-migration-candidate.patch')], cwd=repo, check=True)
subprocess.run(['git', 'apply', str(HERE / 'molly-migration-candidate.patch')], cwd=repo, check=True)
for name, expected in manifest['candidateFiles'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == expected, name + ' candidate mismatch'
subprocess.run(['git', 'diff', '--check'], cwd=repo, check=True)
print(json.dumps({'checkout': str(repo), 'base': manifest['mollyBase'], 'verifiedCandidateFiles': len(manifest['candidateFiles']), 'result': 'patch applied and exact bytes verified'}, indent=2))
